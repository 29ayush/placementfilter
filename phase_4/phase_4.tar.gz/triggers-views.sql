delimiter //

CREATE TRIGGER post_aproval AFTER INSERT ON postings
  FOR EACH ROW
  BEGIN
    INSERT INTO Notifications  a2 = NEW.a1;
    DELETE FROM test3 WHERE a3 = NEW.a1;
    UPDATE test4 SET b4 = b4 + 1 WHERE a4 = NEW.a1;
  END;
//

delimiter ;

delimiter //
CREATE TRIGGER max_round BEFORE INSERT ON PostsApplicants
  FOR EACH ROW
  BEGIN
	DECLARE msg varchar(255);
	IF NEW.RoundNo > (SELECT MaxRounds FROM Postings WHERE PID = NEW.PID) THEN
	SET msg = 'INVALID DATA';
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
	END IF; 
  END;//

delimiter //
CREATE TRIGGER comp_blacklisted BEFORE INSERT ON Company
  FOR EACH ROW
  BEGIN
	DECLARE msg varchar(255);
	IF NEW.Name = (SELECT Name FROM Blacklist WHERE Address = NEW.Address AND Name = NEW.Name) THEN
	SET msg = 'Company is Blacklisted';
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
	END IF; 
  END;//

delimiter //
CREATE TRIGGER job_offer AFTER INSERT ON PostsApplicants
  FOR EACH ROW
  BEGIN
	DECLARE username varchar(255);
	DECLARE note varchar(255);
	IF NEW.RoundNo = (SELECT MaxRounds FROM Postings WHERE PID = NEW.PID) AND NEW.Status = "Passed" THEN
	SET username = (select username FROM Student WHERE Rollno = NEW.RollNo);
	SET note = CONCAT("You have been selected for Post",NEW);
	INSERT INTO Notifications (Username,notify) values (username,note);
	END IF; 
  END;//

delimiter //
CREATE TRIGGER offer_expiry AFTER INSERT ON offerdetails
  FOR EACH ROW
  BEGIN
	DECLARE username varchar(255);
	DECLARE note varchar(255);
	IF NEW.RoundNo = (SELECT MaxRounds FROM Postings WHERE PID = NEW.PID) AND NEW.Status = "Passed" THEN
	SET username = (select username FROM Student WHERE Rollno = NEW.RollNo);
	SET note = CONCAT("You have been selected for Post",NEW);
	INSERT INTO Notifications (Username,notify) values (username,note);
	END IF; 
  END;//
