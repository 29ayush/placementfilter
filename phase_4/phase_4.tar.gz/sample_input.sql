call createuserstudent("pass123","29ayush","Ayush","Mittal",111501035,"29ayush@gmail.com",NULL,90,"M","CSE","BTECH",9.12,NULL,00000,1)//
